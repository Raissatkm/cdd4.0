"""Desafio
problema: Dados s valores de horários abaixo, decifre a lógica e faça um codigo para executar
entrada01 3:45
entrada02 14:20
saida 06:05"""

"""hour1 = int(input("digite a primeira hora"))
minute1 = int(input("digite o primeiro minuto"))
hour2 = int(input("digite o segundo horario"))
minute2 = int(input("digite o segundo minuto"))

finalMinute = minute1 + minute2
finalHour = hour1 + hour2

if (finalMinute >= 60):
    finalMinute = finalMinute - 60
    finalHour = finalHour + 1

if (finalHour >= 12):
    finalHour = finalHour - 24

print(f"{finalHour}:{finalMinute})"""

h1 = int(input("informe a hora 1:"))
min1 = int(input("informe o minuto 1:"))
h2 = int(input("informe a hora 2:"))
min2 = int(input("informe o minuto 2:"))

if h1 > 12:
    h1 = h1 - 12
if h2 > 12:
    h2 = h2 -12
hora = h1 + h2
if hora > 12:
    hora = hora - 12
minutos = min1 + min2
if minutos >= 60:
    minutos = minutos -60
    hora = hora +1
    hora = hora +1
print(hora, minutos)


