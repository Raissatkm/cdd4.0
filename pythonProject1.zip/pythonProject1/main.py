Gasolina = 5.80
Etanol = 4.90

litros = float(input("digite a quantidade de litros  vendidos:"))
nomedocombustivel = input("digite o nome do combustivel utilizado:")

if nomedocombustivel == 'G' or nomedocombustivel == 'g':
    total = litros * Gasolina
    print("voce gastou", total)
elif nomedocombustivel == 'E' or nomedocombustivel == 'e':
    total = litros * Etanol
    print("voce gastou", total)
else:
    print("invalido")