# for (int x=0; x<10; x++) (for x int Range (0, 10 , 1):)
"""for r in range(100, 0, -1):
    print(r)"""
""" problema:
Ler uma variavel de número inteiro e mostrar a tabuada de multiplicação desse número
"""
numero = int(input("Digite o numero"))
for r in range(1,11,1):
    res = r * numero
    print(f"{r}X {numero} = {res}")
