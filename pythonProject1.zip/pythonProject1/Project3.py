numero1 = float(input("Digite o primeiro numero:"))
numero2 = float(input("Digite o Segundo numero:"))

soma = (numero1+numero2)
subtracao = (numero1-numero2)
multiplicacao = (numero1*numero2)
divisao = (numero1/numero2)

print(f"O resultado da sua operação de soma é {soma}")
print(f"O resultado da sua operação de subtracao é {subtracao}")
print(f"O resultado da sua operação de multiplicacao é {multiplicacao}")
print(f"O resultado da sua operação de divisao é {divisao}")

