idade = int(input("Digite a sua idade:"))
mes = int(input("Digite o mês do seu nascimento:"))
anoAtual = 2024
mesAtual = 4
if mes >= mesAtual:
    anoNacimento = (anoAtual -idade)-1
else:
    anoNacimento = (anoAtual - idade)
print(anoNacimento)
