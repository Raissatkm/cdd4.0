nometime1 = input("Digite o nome do nometime1:")
nometime2 = input("Digite o nome do nometime2:")

golsT1 = int(input(f"Digite o numero de gols do primeiro {nometime1}"))
golsT2 = int(input(f"Digite o numero de gols do segundo {nometime2}"))

if golsT1 > golsT2:
    print(f"mostre o time vencedor {nometime1}")
elif golsT2 > golsT1:
    print(f"mostra o time vencedor {nometime2}")
else:
    print(f"mostra empate")

