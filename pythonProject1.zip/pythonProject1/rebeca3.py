num1 = int(input("Digite um numero: "))
num2 = int(input("Digite um numero: "))
num3 = int(input("Digite um numero: "))

if num1 > num2 and num1 > num3:
    print("O numero 1 é maior:")
elif num2 > num3 and num2 > num1:
    print("O numero 2 é maior:")
else:
    print("O numero 3 é maior:")





