r = "S"
while r == "S":
n1 = float(input("digite sua a nota da primeira avaliação:"))
n2 = float(input("digite a nota da segunda avaliação:"))

while n1 <0 or n1 >10:
    print("error")
    n1 = int(input("digite a nota novamente"))
while n2 <0 or n2 >10:
    print("error")
    n2 = int(input("digite a nota novamente"))

media = (n1 + n2) / 2
print(media)
r = input("Deseja repetir a media?")




