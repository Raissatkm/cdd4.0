num1 = float(input("Digite o primeiro numero:"))
num2 = float(input("Digite o Segundo numero:"))

if num1 > num2:
    print(num2, num1)
else:
    print(num1, num2)