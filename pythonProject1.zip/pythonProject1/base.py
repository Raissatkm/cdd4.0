"""Faça um código que receba o valor da base e da altura de um triangulo e calcule sua aréa, usando a formula de basc"""
"""menu = 4

while menu != 3:
    menu = int(input("1 calcule a area do quadrado ou 2 calcule a area do triangulo, é mostre sua saida utilizando 3 :"))
    if menu == 1:
        base = float(input("Digite o valor do base do quadrado:"))
        lado = float(input("Digite o valor de lado:"))
        area = (base * lado)
        print(area)
    elif menu == 2:
        base = float(input("Digite o valor da base do triangulo:"))
        altura = float(input("Digite o valor da altura:"))
        area = (base * altura)/2
        print(area)"""
menu = 4
while menu != 3:
    menu = int(input("Digite 1 para triangulo \n: "
                    "Digite 2 para quadrado \n: "
                    "Digite 3 para sair: "))
    if menu ==3:
        base = float(input("informe a base:"))
        altura = float(input("informe a altura:"))
        areT = (base * altura)/2
        print(areT)
    elif menu ==2:
        lado = float(input("informe o lado:"))
        areaQ = lado*2
        print(areaQ)
    elif menu == 3:
        print("Volta sempre!")







