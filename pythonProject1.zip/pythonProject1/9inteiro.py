'''n1 = float(input("Digite um numero do tipo int:"))
print(f"O seu antercessor {n1-1} e seu sucessor {n1 +1}")
'''
anos = 2024
idade = int(input("Digite a sua idade:"))
mes = int(input("Digite o mes de nascimento:"))
dia = int(input("Digite o dia: "))



