media = (nota1+nota2)
if media>=7:
    print("aprovado")
else:
    print("reprovado")