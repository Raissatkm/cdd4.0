nomeCompleto = input("Digite seu nome:")
nota1 = float(input("Digite a primeira nota:"))
nota2 = float(input("Digite a segunda nota:"))

media = (nota1+nota2)/2
print("Nome do aluno:", nomeCompleto)
print("media do aluno: ", media)
