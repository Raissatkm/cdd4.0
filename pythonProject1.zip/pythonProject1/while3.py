contador = 0
senha = 23

digiteSenha = int(input("digite sua senha"))
if digiteSenha == senha:
    print("senha correta!")

while senha != digiteSenha:
    digiteSenha = int(input("senha errada, digite outra senha!"))
    contador = contador + 1
    if contador == 2 and senha != digiteSenha:
        print("senha invalida, cartão bloqueado")
        break