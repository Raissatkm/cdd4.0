"""Problema:
Faça um código para ler 2 valores e
realize a divisão do primeiro pelo
segundo valor recebido, caso o
segundo valor digitado, seja zero ,
solicite novamente o valor, informando
que só aceitaremos valores diferentes
de zero."""

v1 = float(input("Digite o primeiro valor:"))
v2 = float(input("Digite o segundo valor:"))

while v2 == 0:
    v2 = int(input("invalido digite novamente o valor"))
divisão = v1 / v2





