numero = int(input("Digite um numero:"))
if numero != 0:
    print("positivo")
elif numero ==0:
    print("Não pode ser zero digite outro.")
else:
    print("negativo")