"""n = int(input("Digite um numero:"))
for r in range(1, n+1, 1):
    print(r, end= "-")"""

"""h = 0
for r in range(10):
    num = int(input("digite um numero"))
if num < 0:
    h = h + 1
print(h)"""

dentro = 0
fora = 0
for r in range(0, 10, 1):
    num = int(input("digite o numero"))
    if num >= 10 and num <= 20:
     dentro = dentro + 1
else:
    fora = fora + 1
print("dentro", dentro, "\n" "fora:" .fora)
