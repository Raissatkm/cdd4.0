soma = 0
c = 0
qtdocentes = 0
qtdocentes = int(input("quantos alunos tem na sala:"))
while c < qtdocentes:
    valor = float(input("Digite um numero:"))
    soma += valor
    c += 1
media = soma / 10
print("A Soma é : ", media)

"""somaNotas = 0
c = 0
for x in range(10):

    n = float(input("Digite uma nota"))
    if n>= 0 and n <=10:
        somaNotas = somaNotas + n
        c = c + 1
media = somaNotas + c
print(media)"""