num1 = float(input("Digite o primeiro numero:"))
num2 = float(input("Digite o Segundo numero:"))

if num1 == num2:
    print("numeros iguais")
else:
    print("numeros diferentes")

"""num1 = float(input("Digite o primeiro numero:"))
num2 = float(input("Digite o Segundo numero:"))

if num1==num2:
    print("Numeros são iguais")
else:
    if num1 > num2
    print(num2,num1)
    else:
    print(num1, num2)"""