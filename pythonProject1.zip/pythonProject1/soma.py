n1 = int(input("Digite um numero:"))
n2 = int(input("Digite um numero:"))
n3 = int(input("Digite um numero:"))
n4 = int(input("Digite um numero:"))

media = (n1 + n2 + n3 + n4)/4
print(media)

"""
for x in range(4)
    n = float(input("digite um número:"))
    soma = soma + n 
media = soma/4
print(media, soma)
"""