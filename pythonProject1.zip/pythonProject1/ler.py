"""somaNotas = 0
for x in range(10):
    n = float(input("Digite uma nota:"))
    somaNotas = somaNotas + n
media = somaNotas/10
"""

somaNotas = 0
c = 0
for x in range(10):

    n = float(input("Digite uma nota"))
    if n>= 0 and n <=10:
        somaNotas = somaNotas + n
        c = c + 1
media = somaNotas + c
print(media)