numero = int(input("Digite o numero"))

if numero % 2 == 0:
    print("PAR")
else:
    print("IMPAR")