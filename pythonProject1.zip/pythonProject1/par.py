"""Crie um algoritmo que leia um número e diga se ele é par ou impar """

num = int(input("Digite um numero:"))
if num %2 == 0:
    print("Par")
else:
    print("impar")
